# Prazo Claro — apresentação do TG II

Autora: Kezia Calixto. FATEC Campinas, Análise e Desenvolvimento de Sistemas.
Orientação: Prof. Eduardo Felipe Fonseca de Freitas. Edição: 24/10/2026.

O PowerPoint da apresentação tem 20 slides, incluindo dois de apoio, com notas de fala e fontes. O roteiro sugere um ensaio de 16 min 5 s, incluindo demonstração; confirmar o tempo oficial com a orientação.

O PowerPoint do pôster tem uma página de aproximadamente 90 × 100 cm, conforme o modelo institucional fornecido. Os dois PDFs correspondem aos respectivos arquivos editáveis. Solicitar escala 100% à gráfica e confirmar dimensões, acabamento e margem de segurança antes de imprimir. O PDF do pôster é RGB, sem sangria ou certificação PDF/X.

Os e-mails acadêmicos da autora e do orientador não foram fornecidos e foram omitidos. Confirmar os contatos antes da submissão, se exigidos. O link do sistema está nos materiais. Revisar textos, ensaiar a fala e preparar uma conta de teste para a demonstração. Guardar o PDF para uma apresentação sem internet.

Editar o PPTX não atualiza automaticamente o PDF, o roteiro ou o relatório. Depois de mudanças, exportar e conferir novamente. Textos e tabelas são editáveis; logotipos e captura da interface são imagens incorporadas. Originais institucionais completos, configuração privada e código-fonte do aplicativo não fazem parte deste pacote.

Dados técnicos e limites seguem o relatório: base funcional 9632fd2 e CI 40061653068. Calendários parciais e revisão jurídica pendente. Recebimento externo de lembrete ainda sujeito a aceite no corte documental. Estes materiais não comprovam aprovação acadêmica ou certificação jurídica.
