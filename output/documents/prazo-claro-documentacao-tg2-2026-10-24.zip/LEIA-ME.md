# Prazo Claro — documentação TG2

Kezia Calixto. ADS, FATEC Campinas. Orientação: Prof. Eduardo Felipe Fonseca de Freitas.
Edição de 24/10/2026, para revisão da autora e do orientador.

Abra os arquivos Word/PDF em output/documents/. O guia é o material operacional curto; o relatório documenta concepção, engenharia, implementação, resultados e limites.
O projeto LaTeX está em docs/relatorio-tg2/: abra main.tex como documento principal. Capítulos, referências e figuras estão incluídos. Não exige BibTeX/Biber.
Os formatos usam a mesma fonte narrativa e têm paginação própria. Leia o README antes de regenerar o sumário do Word.

Este pacote contém documentação, não o aplicativo inteiro nem backup de contas/banco. Evidências completas e código estão no repositório privado TG-KEZIA2, cujo acesso depende do proprietário.
Não contém credenciais ou originais institucionais. Ficha catalográfica, aprovação, revisão jurídica e aceites pendentes exigem seus responsáveis. O recebimento do lembrete externo não foi confirmado no corte da evidência.
O manifesto identifica os arquivos por SHA-256.
