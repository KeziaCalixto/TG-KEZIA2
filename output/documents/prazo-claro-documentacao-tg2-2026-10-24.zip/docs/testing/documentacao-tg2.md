# Documentação de entrega e TG2 — 24/10/2026

## Conferência final dos artefatos

Todas as páginas dos PDFs foram revisadas visualmente ao longo da geração e da conferência dos ajustes: guia 10, relatório Word 51 e relatório LaTeX 52. Sem página vazia, cortes ou sobreposição remanescentes. A conferência estrutural encontrou 21 chaves bibliográficas citadas, nenhuma citação sem referência e nenhuma referência sem citação. A paginação Word final tem 91 correspondências e zero diferenças. Originais institucionais preservados fora do pacote documental.

O pacote `output/documents/prazo-claro-documentacao-tg2-2026-10-24.zip` contém Word, PDFs e projeto editável, com manifesto por arquivo e SHA-256 externo. Verificação de integridade ZIP e de cada hash aprovada; lista restrita sem .env, .git, executáveis temporários ou originais institucionais. O pacote não equivale ao código-fonte completo do aplicativo ou backup do banco.

O projeto LaTeX foi extraído do ZIP para uma pasta temporária nova e compilado novamente com `--only-cached`: exit 0, 52 páginas, sem depender de arquivos externos do repositório ou de novos downloads. Essa verificação comprova o fechamento do conjunto de fontes e figuras empacotado; os avisos tipográficos ambientais são os já descritos abaixo.

## Guia do aplicativo

Fonte em `docs/entrega/guia-do-aplicativo.md`; Word e PDF em `output/documents/`, edição 24/10/2026. Guia de dez páginas com cobertura, uso, conta, histórico, lembretes, demonstração, arquitetura, instalação, evidências e pendências.

Gerado com Python do runtime fornecido pelo aplicativo e python-docx. DOCX convertido pelo LibreOffice 26.2 da imagem Docker local `stirlingtools/stirling-pdf`, sem rede e com montagens restritas aos documentos temporários e fontes. Renderização pelo `render_docx.py` da skill documents e Poppler. Dez páginas efetivamente renderizadas e inspecionadas: sem cortes, sobreposição ou tabelas fora das margens. Nenhuma alteração do código funcional ou reexecução dos testes do app foi necessária.

Base funcional 9632fd2; evidências de CI já registradas nos documentos de publicação. Os números 256/146/67 e um omitido pertencem à execução anterior identificada, não a novos testes desta documentação. Recebimento externo continua pendente; a conferência de 13h44 encontrou o novo lembrete de 24/10 às 18h agendado, sem tentativa ou erro, com Cron ativo. Não foi enviado e-mail adicional.

## Relatório acadêmico

Solicitados relatório completo em Word/PDF e projeto LaTeX, além do guia. Manual FATEC Campinas de maio de 2024, template e rascunhos originais preservados. Autora confirmou Kezia Calixto, ADS e orientação do Prof. Eduardo Felipe Fonseca de Freitas. O relatório deve rastrear concepção, requisitos, arquitetura, modelagem, implementação, testes, resultados e limitações, sem inventar pesquisa com participantes, revisão jurídica, custos medidos, aprovação ou ficha catalográfica.

Texto compartilhado em `docs/relatorio-tg2/conteudo.md`, sete capítulos e seis apêndices, cerca de 8,8 mil palavras, 21 referências, oito diagramas de engenharia e duas capturas de interface identificadas. Resumo em português com 219 palavras e abstract com 209, quatro palavras-chave em cada idioma. A matriz institucional registra as correspondências e as decisões de apresentação.

Word com A4, Times New Roman 12, títulos principais 14, margens 3/3/2/2 cm, corpo 1,5 e recuo 1,25 cm. PDF com **51 páginas físicas**; capa não contada, folha de rosto contada como um e primeira numeração visível na introdução. `verificar_paginacao.py` localizou os 91 títulos/legendas e confirmou zero divergências entre paginação e listas materializadas. A revisão corrigiu borda de tema herdada, página vazia, código justificado, alinhamento das referências e fonte separada do quadro.

O compilador integrado retornou falha técnica do sandbox Windows antes de compilar a fonte. A alternativa MiKTeX existente não tinha os pacotes de idioma/fonte necessários; instalação automática permaneceu desligada. O Tectonic 0.17.0+20260731 fornecido pelo aplicativo foi executado a partir de uma cópia temporária acessível no workspace, obtendo somente dependências TeX em seu cache. A compilação efetiva retornou exit 0 e **52 páginas**. Sumário, listas e referências foram estabilizados por recompilações automáticas. Travessões, ordinais e símbolo de parágrafo foram corrigidos após inspeção visual. O log final não registra caixas excedentes, citações indefinidas ou caracteres ausentes; avisos de espaçamento `Underfull hbox` e aviso de Fontconfig do ambiente permanecem, com fontes incorporadas e páginas legíveis.

Comandos de geração e conferência, executados com o Python do runtime de documentos:

```text
python docs/relatorio-tg2/gerar_documentos.py --pages docs/relatorio-tg2/paginacao-word.json
python docs/relatorio-tg2/verificar_paginacao.py PDF_WORD
tectonic -X compile docs/relatorio-tg2/main.tex --outdir tmp/relatorio-tg2/latex --keep-logs --keep-intermediates
```

`PDF_WORD` representa o PDF real renderizado do Word, não um arquivo de HTML equivalente. O adaptador de conversão foi o mesmo descrito para o guia. O Poppler produziu as imagens dos dois PDFs para revisão visual. As imagens de QA e executáveis temporários ficaram em `tmp/`, ignorado pelo Git. Nenhuma instalação completa de TeX, alteração de código funcional, migration, envio de e-mail ou mudança de produção foi necessária.

A revisão acadêmica final pela autora e orientação continua necessária. Não há declaração de aprovação da banca, ficha catalográfica produzida pela biblioteca, revisão jurídica concluída ou pesquisa de usuários executada. O estado do lembrete mantém o corte de evidência de 13h44, sem presumir recebimento posterior.
